import 'package:flutter/material.dart';
import 'package:teste/models/character_model.dart';
import 'package:teste/screens/battle_screen.dart' as battle;
import 'package:provider/provider.dart';
import 'package:teste/providers/game_state.dart';

class QuestsScreen extends StatelessWidget {
  QuestsScreen({super.key});

  final List<EnemyCharacter> bosses = [
    EnemyCharacter(
      name: 'Círculo Vermelho da Fúria',
      texturePath: 'images/red_circle_texture.png',
      hp: 300,
      attack: 20,
    ),
    EnemyCharacter(
      name: 'Círculo Sombrio do Abismo',
      texturePath: 'images/dark_circle_texture.png',
      hp: 500,
      attack: 12,
      defense: 8,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final gameState = Provider.of<GameState>(context, listen: false);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Selecione o Chefe da Missão',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.grey[900],
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: const AssetImage("images/background_quests.png"),
            fit: BoxFit.cover,
          ),
        ),
        child: ListView.builder(
          padding: const EdgeInsets.all(16.0),
          itemCount: bosses.length,
          itemBuilder: (context, index) {
            final boss = bosses[index];
            return _buildBossCard(context, boss, gameState);
          },
        ),
      ),
    );
  }

  Widget _buildBossCard(
    BuildContext context,
    EnemyCharacter boss,
    GameState gameState,
  ) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16.0),
      color: const Color.fromARGB(163, 0, 0, 0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 6,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          children: [
            CircleAvatar(
              radius: 35,
              backgroundImage: AssetImage(boss.texturePath),
              backgroundColor: Colors.grey[800],
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    boss.name,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'HP: ${boss.maxHp} | ATK: ${boss.attack} | DEF: ${boss.defense}',
                    style: TextStyle(color: Colors.red.shade200, fontSize: 14),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 16),
            ElevatedButton(
              onPressed: () {
                if (gameState.selectedHero != null) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => battle.BattleScreen(enemy: boss),
                    ),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Por favor, escolha um herói antes de iniciar uma missão!',
                      ),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.shade800,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 12,
                ),
              ),
              child: const Text('Lutar!'),
            ),
          ],
        ),
      ),
    );
  }
}
